package com.passion.fmbg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FmbgApplication {

	public static void main(String[] args) {
		SpringApplication.run(FmbgApplication.class, args);
	}

}
